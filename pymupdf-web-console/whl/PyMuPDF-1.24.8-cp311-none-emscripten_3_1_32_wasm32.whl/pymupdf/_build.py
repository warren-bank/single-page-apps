mupdf_location='git:--branch master https://github.com/ArtifexSoftware/mupdf.git'
